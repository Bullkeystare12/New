import discord
from discord.ext import commands
from discord import app_commands
import json, datetime

class Daily(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="daily", description="Claim your daily reward.")
    async def daily(self, interaction: discord.Interaction):
        user_id = str(interaction.user.id)
        try:
            with open("economy.json", "r") as f:
                data = json.load(f)
        except FileNotFoundError:
            data = {}

        now = datetime.datetime.utcnow()
        last_claim = data.get(user_id, {}).get("last_daily")

        if last_claim and (now - datetime.datetime.fromisoformat(last_claim)).total_seconds() < 86400:
            elapsed = (now - datetime.datetime.fromisoformat(last_claim)).total_seconds()
            remaining = int(86400 - elapsed)
            hours, remainder = divmod(remaining, 3600)
            minutes, seconds = divmod(remainder, 60)
            await interaction.response.send_message(f"⏳ You've already claimed your daily reward. Come back in **{hours}h {minutes}m {seconds}s**.")
            return

        data.setdefault(user_id, {})
        data[user_id]["balance"] = data[user_id].get("balance", 0) + 100
        data[user_id]["last_daily"] = now.isoformat()

        with open("economy.json", "w") as f:
            json.dump(data, f, indent=4)

        await interaction.response.send_message("✅ You received 100 coins!")

async def setup(bot):
    await bot.add_cog(Daily(bot))