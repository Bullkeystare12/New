import discord
from discord.ext import commands
from discord import app_commands
import json

class Profile(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="profile", description="Show your economy profile.")
    async def profile(self, interaction: discord.Interaction):
        user_id = str(interaction.user.id)
        try:
            with open("economy.json", "r") as f:
                data = json.load(f)
        except FileNotFoundError:
            data = {}

        user_data = data.get(user_id, {})
        balance = user_data.get("balance", 0)

        embed = discord.Embed(title=f"{interaction.user.display_name}'s Profile", color=discord.Color.blue())
        embed.set_thumbnail(url=interaction.user.display_avatar.url)
        embed.add_field(name="💰 Balance", value=f"{balance} coins", inline=True)

        await interaction.response.send_message(embed=embed)

async def setup(bot):
    await bot.add_cog(Profile(bot))