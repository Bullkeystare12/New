import discord

from discord import app_commands

from discord.ext import commands

import random

import json

import os

ECONOMY_FILE = "economy.json"

class Battle(commands.Cog):

    def __init__(self, bot):

        self.bot = bot

    @app_commands.command(name="battle", description="Battle another user's animal.")

    @app_commands.describe(opponent="The user you want to battle.")

    async def battle(self, interaction: discord.Interaction, opponent: discord.Member):

        user_id = str(interaction.user.id)

        opponent_id = str(opponent.id)

        if not os.path.exists(ECONOMY_FILE):

            return await interaction.response.send_message("No data available to battle.", ephemeral=True)

        with open(ECONOMY_FILE, "r") as f:

            data = json.load(f)

        user_pets = data.get(user_id, {}).get("pets", [])

        opponent_pets = data.get(opponent_id, {}).get("pets", [])

        if not user_pets or not opponent_pets:

            return await interaction.response.send_message("Both users need at least one pet to battle!", ephemeral=True)

        winner = random.choice([interaction.user.name, opponent.name])

        await interaction.response.send_message(f"⚔️ Battle Result: **{winner}** wins the animal battle!")

async def setup(bot):

    await bot.add_cog(Battle(bot))