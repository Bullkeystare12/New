import discord

from discord.ext import commands

from discord import app_commands

import random

from utils.economy import get_user_data, overwrite_user_data  # ✅ Fixed import

class hunt(commands.Cog):

    def __init__(self, bot):

        self.bot = bot

    # Prefix command: &hunt

    @commands.command(name="hunt")
    

    async def hunt(self, ctx):
        print("hunt text cmd used")

        user_id = str(user_id)

        data = get_user_data(user_id)

        animals = ["deer", "rabbit", "boar", "wolf", "bear"]

        caught = random.choice(animals)

        inventory = data.get("inventory", [])

        inventory.append(caught)

        data["inventory"] = inventory

        overwrite_user_data(user_id, data)

        msg = f"🦌 You went hunting and caught a **{caught}**!"

        await ctx.send(msg)

    # Slash command: /hunt

    @app_commands.command(name="hunt", description="Go hunting and catch animals!")
    
   

    async def hunt(self, interaction: discord.Interaction):
        print("hunt slash cmd used")

        await interaction.response.defer()
        print("interaction deferred")

        user_id = str(interaction.user.id)
        print("got user id")

        data = get_user_data(user_id)
        print("got user data")

        animals = ["deer", "rabbit", "boar", "wolf", "bear"]
        print("got animals")

        caught = random.choice(animals)
        print("got random animal")

        inventory = data.get("inventory", [])
        print("got inventory")

        inventory.append(caught)
        print("changed inventory")

        data["pets"] = inventory
        print("changed inventory in data")

        overwrite_user_data(user_id, data)
        print("overwrite user data ")

        msg = f"🦌 You went hunting and caught a **{caught}**!"
        print("set msg")


        


        await interaction.followup.send(msg)
        print("sent message")

# Load the Cog

async def setup(bot):

    await bot.add_cog(hunt(bot))