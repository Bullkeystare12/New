import discord
from discord.ext import commands
from discord import app_commands
import aiohttp
from PIL import Image, ImageSequence, ImageDraw
import io
import os
import base64

GOLD = 0xFFD700

class Pat(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="pat", description="Pet someone's avatar")
    async def pat(self, interaction: discord.Interaction, member: discord.Member):
        await interaction.response.defer(thinking=True)
        try:
            print("[DEBUG] Pat command triggered.")
            print(f"[DEBUG] Target member: {member} (ID: {member.id})")

            # Get avatar
            avatar_url = member.display_avatar.replace(format='png', size=128).url
            print(f"[DEBUG] Avatar URL: {avatar_url}")

            async with aiohttp.ClientSession() as session:
                print("[DEBUG] Downloading avatar...")
                async with session.get(avatar_url) as av_resp:
                    print(f"[DEBUG] Avatar response status: {av_resp.status}")
                    if av_resp.status != 200:
                        raise Exception("Couldn't download avatar.")
                    avatar_bytes = await av_resp.read()
                    print("[DEBUG] Avatar downloaded successfully.")

            avatar_img = Image.open(io.BytesIO(avatar_bytes)).convert("RGBA")
            print("[DEBUG] Avatar image opened and converted to RGBA.")

            # Circle mask
            base_size = (64, 64)
            mask = Image.new("L", base_size, 0)
            draw = ImageDraw.Draw(mask)
            draw.ellipse((0, 0) + base_size, fill=255)
            print("[DEBUG] Circular mask created.")

            template_path = os.path.join("templates", "pat_template.gif")
            print(f"[DEBUG] Template path: {template_path}")

            if not os.path.isfile(template_path):
                raise FileNotFoundError("GIF template not found at ./templates/pat_template.gif")
            print("[DEBUG] Template file found.")

            hand_gif = Image.open(template_path)
            print("[DEBUG] Template GIF opened.")
            frames = []

            squeeze_values = [1.0, 0.92, 0.85, 0.92, 1.0]

            for idx, frame in enumerate(ImageSequence.Iterator(hand_gif)):
                print(f"[DEBUG] Processing frame {idx}")
                frame = frame.convert("RGBA")
                canvas = Image.new("RGBA", frame.size, (0, 0, 0, 0))

                scale = squeeze_values[idx % len(squeeze_values)]
                new_size = (base_size[0], int(base_size[1] * scale))
                avatar_scaled = avatar_img.resize(new_size, Image.LANCZOS)
                mask_scaled = mask.resize(new_size, Image.LANCZOS)
                avatar_scaled.putalpha(mask_scaled)

                x, y = 40, 60 + (base_size[1] - new_size[1])
                canvas.paste(avatar_scaled, (x, y), avatar_scaled)
                canvas.alpha_composite(frame)
                frames.append(canvas)

            print("[DEBUG] All frames processed. Creating GIF...")

            b = io.BytesIO()
            frames[0].save(
                b,
                format="GIF",
                save_all=True,
                append_images=frames[1:],
                duration=hand_gif.info.get("duration", 40),
                loop=0,
                disposal=2,
                transparency=0
            )
            b.seek(0)
            print("[DEBUG] GIF created and saved to buffer.")

            # Upload to ImgBB
            imgbb_api_key = "dc924fb2a0c50c7fcff97ebe261d51e7"
            image_base64 = base64.b64encode(b.getvalue()).decode("utf-8")
            payload = {
                "key": imgbb_api_key,
                "image": image_base64
            }

            print("[DEBUG] Uploading to ImgBB...")
            async with aiohttp.ClientSession() as session:
                async with session.post("https://api.imgbb.com/1/upload", data=payload) as resp:
                    data = await resp.json()
                    print(f"[DEBUG] ImgBB response: {data}")
                    if not data.get("success"):
                        raise Exception("Failed to upload image to ImgBB.")
                    image_url = data["data"]["url"]
                    print(f"[DEBUG] Image uploaded successfully: {image_url}")

            # Send embed
            embed = discord.Embed(
                title=f"{interaction.user.display_name} pats {member.display_name}!",
                color=GOLD
            )
            embed.set_image(url=image_url)
            await interaction.followup.send(embed=embed)
            print("[DEBUG] Embed sent successfully.")

        except FileNotFoundError as fnf:
            print(f"[ERROR] {fnf}")
            await interaction.followup.send(
                embed=discord.Embed(
                    title="Template Missing",
                    description=str(fnf),
                    color=GOLD
                ),
                ephemeral=True
            )
        except Exception as e:
            print(f"[ERROR] Unexpected error: {e}")
            await interaction.followup.send(
                embed=discord.Embed(
                    title="Unexpected Error",
                    description=f"```{e}```",
                    color=GOLD
                ),
                ephemeral=True
            )

async def setup(bot):
    await bot.add_cog(Pat(bot))