import discord

from discord.ext import commands, tasks

from discord import app_commands

import asyncio

class Vote(commands.Cog):

    def __init__(self, bot):

        self.bot = bot

    @app_commands.command(name="vote", description="Vote for the bot and get rewards!")

    async def vote(self, interaction: discord.Interaction):

        await interaction.response.send_message("📬 Check your DMs for the vote link!", ephemeral=True)

        embed = discord.Embed(

            title="Vote for Fixton Bot",

            description="[Click here to vote on Top.gg](https://top.gg/bot/1396104148356960339?s=07cc30eff1aa8)",

            color=discord.Color.purple()

        )

        embed.set_footer(text="Voting helps our bot grow!")

        view = VoteReminderButtons(user=interaction.user)

        try:

            await interaction.user.send(embed=embed, view=view)

        except discord.Forbidden:

            await interaction.followup.send("❌ I couldn't DM you. Please enable DMs.", ephemeral=True)

class VoteReminderButtons(discord.ui.View):

    def __init__(self, user):

        super().__init__(timeout=60)

        self.user = user

    @discord.ui.button(label="✅ Yes, remind me", style=discord.ButtonStyle.green)

    async def remind_me(self, interaction: discord.Interaction, button: discord.ui.Button):

        if interaction.user != self.user:

            return await interaction.response.send_message("This button isn't for you.", ephemeral=True)

        await interaction.response.send_message("✅ Okay! I'll remind you in 12 hours to vote.", ephemeral=True)

        # Wait 12 hours (12 * 60 * 60 seconds)

        await asyncio.sleep(43200)

        try:

            await self.user.send("🔔 Hey! Don't forget to [vote for Fixton Bot](https://top.gg/bot/1396104148356960339?s=07cc30eff1aa8) again!")

        except discord.Forbidden:

            print(f"Couldn't send reminder to {self.user}")

    @discord.ui.button(label="❌ No thanks", style=discord.ButtonStyle.red)

    async def no_thanks(self, interaction: discord.Interaction, button: discord.ui.Button):

        if interaction.user != self.user:

            return await interaction.response.send_message("This button isn't for you.", ephemeral=True)

        await interaction.response.send_message("👍 No problem! You can vote anytime using /vote.", ephemeral=True)

async def setup(bot):

    await bot.add_cog(Vote(bot))