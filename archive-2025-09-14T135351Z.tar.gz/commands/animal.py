import discord

from discord import app_commands

from discord.ext import commands

import json

import os

ECONOMY_FILE = "economy.json"

class Animal(commands.Cog):

    def __init__(self, bot):

        self.bot = bot

    @app_commands.command(name="animal", description="See your current animals.")

    async def animal(self, interaction: discord.Interaction):

        user_id = str(interaction.user.id)

        if not os.path.exists(ECONOMY_FILE):

            return await interaction.response.send_message("You have no animals yet!", ephemeral=True)

        with open(ECONOMY_FILE, "r") as f:

            data = json.load(f)

        pets = data.get(user_id, {}).get("pets", [])

        if not pets:

            return await interaction.response.send_message("You have no animals yet!", ephemeral=True)

        pet_list = "\n".join(pets)

        await interaction.response.send_message(f"🐾 Your animals:\n{pet_list}", ephemeral=False)

async def setup(bot):

    await bot.add_cog(Animal(bot))