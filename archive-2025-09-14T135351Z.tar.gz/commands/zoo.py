import discord

from discord import app_commands

from discord.ext import commands

import json

import os

ECONOMY_FILE = "economy.json"

class Zoo(commands.Cog):

    def __init__(self, bot):

        self.bot = bot

    @app_commands.command(name="zoo", description="Display all your collected animals.")

    async def zoo(self, interaction: discord.Interaction):

        user_id = str(interaction.user.id)

        if not os.path.exists(ECONOMY_FILE):

            return await interaction.response.send_message("You don't have any animals.", ephemeral=True)

        with open(ECONOMY_FILE, "r") as f:

            data = json.load(f)

        pets = data.get(user_id, {}).get("pets", [])

        if not pets:

            return await interaction.response.send_message("Your zoo is empty.", ephemeral=True)

        pet_counts = {}

        for pet in pets:

            pet_counts[pet] = pet_counts.get(pet, 0) + 1

        desc = "\n".join([f"{emoji}: {count}" for emoji, count in pet_counts.items()])

        embed = discord.Embed(title="🦁 Your Zoo", description=desc, color=discord.Color.blue())

        await interaction.response.send_message(embed=embed)

async def setup(bot):

    await bot.add_cog(Zoo(bot))