import discord
from discord.ext import commands
from utils.load import load_commands

ALLOWED_USERS = {803114661678940190, 1298625835422584894}

async def setup(bot):
    @bot.command(name="reload")
    async def reload(ctx: commands.Context):
        if ctx.author.id not in ALLOWED_USERS:
            embed = discord.Embed(
                title="❌ Access Denied",
                description="You are not authorized to use this command.",
                color=discord.Color.red()
            )
            return await ctx.send(embed=embed)

        try:
            await load_commands(bot)
            embed = discord.Embed(
                title="✅ Commands Reloaded",
                description="All command modules have been reloaded.",
                color=discord.Color.gold()
            )
            print(f"[RELOAD] Reload command used by {ctx.author} ({ctx.author.id})")
            await ctx.send(embed=embed)
        except Exception as e:
            embed = discord.Embed(
                title="⚠️ Reload Failed",
                description=f"An error occurred:\n```{str(e)}```",
                color=discord.Color.red()
            )
            print(f"[RELOAD ERROR] {str(e)}")
            await ctx.send(embed=embed)