import discord  

from discord.ext import commands  

from discord import app_commands  

import json  

  

class Balance(commands.Cog):  

    def __init__(self, bot):  

        self.bot = bot  

  

    @app_commands.command(name="balance", description="Check your balance.")  

    async def balance(self, interaction: discord.Interaction):  

        user_id = str(interaction.user.id)  

  

        try:  

            with open("economy.json", "r") as f:  

                data = json.load(f)  

        except FileNotFoundError:  

            data = {}  

  

        balance = data.get(user_id, {}).get("balance", 0)  

  

        # 👉 Replace with your custom emoji if available  

        custom_emoji = "<:Tc:1400810952093466637>"  # ← Replace with your emoji ID  

        formatted_balance = f"{balance:,}"  # Adds commas like 1,000,000  

  

        # Styled message similar to OwO bot  

        message = f"{custom_emoji} | **{interaction.user.display_name}**, you currently have **{formatted_balance}** TC !"  

  

        await interaction.response.send_message(message)  

  

async def setup(bot):  
    await bot.add_cog(Balance(bot))