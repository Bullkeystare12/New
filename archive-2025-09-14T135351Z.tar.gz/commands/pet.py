import discord

from discord.ext import commands

from discord import app_commands

from discord.ui import View, Select

from utils.economy import overwrite_user_data, get_user_data

class PetSelection(discord.ui.Select):

    def __init__(self, user_id: str, pets: list, interaction: discord.Interaction):

        self.user_id = user_id

        self.interaction = interaction

        options = [

            discord.SelectOption(label=pet, value=pet, description=f"Select {pet} as your active pet.")

            for pet in pets

        ]

        super().__init__(placeholder="Choose your pet...", min_values=1, max_values=1, options=options)

    async def callback(self, interaction: discord.Interaction):

        selected_pet = self.values[0]

        data = get_user_data(self.user_id)

        data["active_pet"] = selected_pet

        overwrite_user_data(self.user_id, data)

        await interaction.response.edit_message(

            content=f"✅ You have selected **{selected_pet}** as your active pet!",

            view=None

        )

class PetSelectionView(View):

    def __init__(self, user_id: str, pets: list, interaction: discord.Interaction):

        super().__init__(timeout=60)

        self.add_item(PetSelection(user_id, pets, interaction))

class Pets(commands.Cog):

    def __init__(self, bot):

        self.bot = bot

    @app_commands.command(name="pet", description="Select a pet from your collection.")

    async def pet(self, interaction: discord.Interaction):

        user_id = str(interaction.user.id)

        data = get_user_data(user_id)

        pets = data.get("pets", [])

        if not pets:

            await interaction.response.send_message("❌ You don't own any pets yet.", ephemeral=True)

            return

        await interaction.response.send_message(

            "🐾 Choose your active pet from the dropdown below:",

            view=PetSelectionView(user_id, pets, interaction),

            ephemeral=True

        )

# Setup function

async def setup(bot):

    await bot.add_cog(Pets(bot))