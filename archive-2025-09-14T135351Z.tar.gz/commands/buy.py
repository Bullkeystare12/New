import json
import discord
from discord.ext import commands
from discord import app_commands

from utils.economy import overwrite_user_data, get_user_data

# Load shop items
def get_shop_items():
    print("[DEBUG] Loading shop items...")
    with open("shop_items.json", "r") as f:
        return json.load(f)

class Buy(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    async def buy_handler(self, interaction: discord.Interaction, item: str):
        print(f"[DEBUG] /buy called by {interaction.user.id} for item '{item}'")
        await interaction.response.defer()

        user_id = str(interaction.user.id)
        data = get_user_data(user_id)

        print("[DEBUG] Fetching shop...")
        shop_lookup = get_shop_items()
        shop = {key.lower(): value for key, value in shop_lookup.items()}
        item_lower = item.lower()

        if item_lower not in shop:
            print("[DEBUG] Invalid item.")
            return await interaction.followup.send("❌ That item doesn't exist in the shop.")

        item_info = shop[item_lower]
        price = item_info["price"]

        if data["balance"] < price:
            print("[DEBUG] Not enough balance.")
            return await interaction.followup.send("💸 You don't have enough money to buy that item.")

        data["balance"] -= price

        if item_info["type"] == "pet":
            data.setdefault("pets", []).append(item_lower)
            print(f"[DEBUG] Added '{item_lower}' to pets.")
        else:
            data.setdefault("inventory", []).append(item_lower)
            print(f"[DEBUG] Added '{item_lower}' to inventory.")

        overwrite_user_data(user_id, data)
        print("[DEBUG] Purchase complete.")
        await interaction.followup.send(f"✅ You bought **{item_lower}** for {price} coins!")

async def setup(bot: commands.Bot):
    cog = Buy(bot)
    await bot.add_cog(cog)

    # Register slash command dynamically and bind to buy_handler
    @bot.tree.command(name="buy", description="Buy an item from the shop")
    @app_commands.describe(item="The item name to purchase")
    async def buy(interaction: discord.Interaction, item: str):
        await cog.buy_handler(interaction, item)

    print("[DEBUG] Registered /buy command.")