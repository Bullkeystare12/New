import json
import discord
from discord import app_commands
from discord.ext import commands

def get_shop_items():
    with open("shop_items.json", "r") as f:
        return json.load(f)

class ShopView(discord.ui.View):
    def __init__(self, shop_items, author_id):
        super().__init__(timeout=60)
        self.shop_items = list(shop_items.items())
        self.author_id = author_id
        self.page = 0
        self.items_per_page = 5
        self.total_pages = (len(self.shop_items) - 1) // self.items_per_page + 1

    def get_embed(self):
        embed = discord.Embed(title="🛒 Shop Items", color=discord.Color.gold())
        start = self.page * self.items_per_page
        end = start + self.items_per_page
        for item_name, item_info in self.shop_items[start:end]:
            name_lower = item_name.lower()
            price = item_info.get("price", "Unknown")
            item_type = item_info.get("type", "Unknown")
            description = item_info.get("description", "No description.")
            embed.add_field(
                name=f"**{name_lower}**",
                value=f"**Type:** {item_type}\n**Price:** {price} <:Tc:1400810952093466637>\n**Description:** {description}",
                inline=False
            )
        embed.set_footer(text=f"Page {self.page + 1}/{self.total_pages}")
        return embed

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        return interaction.user.id == self.author_id

    @discord.ui.button(label="⬅️", style=discord.ButtonStyle.blurple)
    async def previous(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self.page > 0:
            self.page -= 1
            await interaction.response.edit_message(embed=self.get_embed(), view=self)

    @discord.ui.button(label="➡️", style=discord.ButtonStyle.blurple)
    async def next(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self.page < self.total_pages - 1:
            self.page += 1
            await interaction.response.edit_message(embed=self.get_embed(), view=self)

class Shop(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="shop", description="Check what items are available in the shop.")
    async def shop(self, interaction: discord.Interaction):
        shop_items = get_shop_items()
        view = ShopView(shop_items, interaction.user.id)
        await interaction.response.send_message(embed=view.get_embed(), view=view)

async def setup(bot):
    await bot.add_cog(Shop(bot))