import discord
from discord.ext import commands
from discord import app_commands

from utils.economy import load_data  # Ensure this has a read_data() function

class Leaderboard(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="leaderboard", description="Show the top 10 richest users and your rank")
    async def leaderboard(self, interaction: discord.Interaction):
        user_id = str(interaction.user.id)

        try:
            data = load_data()
        except Exception as e:
            await interaction.response.send_message(f"⚠️ Failed to load economy data: {e}", ephemeral=True)
            return

        # Build list of (user_id, balance)
        rankings = [(uid, user_data.get("balance", 0)) for uid, user_data in data.items()]
        rankings.sort(key=lambda x: x[1], reverse=True)

        # Find user rank
        user_rank = next((i + 1 for i, (uid, _) in enumerate(rankings) if uid == user_id), None)
        top_10 = rankings[:10]

        embed = discord.Embed(title="🏆 Top 10 Richest Users", color=discord.Color.gold())

        for i, (uid, balance) in enumerate(top_10, start=1):
            try:
                member = await self.bot.fetch_user(int(uid))
                name = member.name
            except:
                name = f"User ID: {uid}"
            embed.add_field(name=f"#{i} - {name}", value=f"💰 {balance} coins", inline=False)

        if user_rank:
            user_balance = data.get(user_id, {}).get("balance", 0)
            embed.set_footer(text=f"You are ranked #{user_rank} with 💰 {user_balance} coins.")
        else:
            embed.set_footer(text="You're not ranked yet. Earn some coins to get on the board!")

        await interaction.response.send_message(embed=embed, ephemeral=False)

async def setup(bot):
    await bot.add_cog(Leaderboard(bot))