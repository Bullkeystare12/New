import discord
from discord.ext import commands
from discord import app_commands
import json

class Give(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="give", description="Give coins to another user.")
    async def give(self, interaction: discord.Interaction, member: discord.Member, amount: int):
        giver_id = str(interaction.user.id)
        receiver_id = str(member.id)

        try:
            with open("economy.json", "r") as f:
                data = json.load(f)
        except FileNotFoundError:
            data = {}

        if data.get(giver_id, {}).get("balance", 0) < amount:
            await interaction.response.send_message("❌ You don't have enough coins.")
            return

        data.setdefault(giver_id, {})
        data.setdefault(receiver_id, {})
        data[giver_id]["balance"] -= amount
        data[receiver_id]["balance"] = data[receiver_id].get("balance", 0) + amount

        with open("economy.json", "w") as f:
            json.dump(data, f, indent=4)

        await interaction.response.send_message(f"💸 You gave {amount} coins to {member.display_name}!")

async def setup(bot):
    await bot.add_cog(Give(bot))